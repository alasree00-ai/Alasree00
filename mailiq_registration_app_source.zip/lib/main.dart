import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

const supabaseUrl = String.fromEnvironment('SUPABASE_URL');
const supabaseAnonKey = String.fromEnvironment('SUPABASE_ANON_KEY');

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  if (supabaseUrl.isNotEmpty && supabaseAnonKey.isNotEmpty) {
    await Supabase.initialize(url: supabaseUrl, anonKey: supabaseAnonKey);
  }
  runApp(const MailiqApp());
}

bool get backendReady => supabaseUrl.isNotEmpty && supabaseAnonKey.isNotEmpty;

class MailiqApp extends StatelessWidget {
  const MailiqApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'التسجيل الإلكتروني - فرع المعيلق',
      locale: const Locale('ar'),
      supportedLocales: const [Locale('ar'), Locale('en')],
      localizationsDelegates: GlobalMaterialLocalizations.delegates,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF174766)),
        scaffoldBackgroundColor: const Color(0xFFF5F7FA),
        fontFamily: 'Arial',
        appBarTheme: const AppBarTheme(
          backgroundColor: Color(0xFF174766),
          foregroundColor: Colors.white,
          centerTitle: true,
        ),
      ),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int index = 0;
  final pages = const [DashboardPage(), StudentsPage(), AnnualRegistrationPage(), NoticesPage()];

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('جامعة أم درمان الإسلامية'),
          bottom: const PreferredSize(
            preferredSize: Size.fromHeight(28),
            child: Padding(
              padding: EdgeInsets.only(bottom: 8),
              child: Text('فرع المعيلق | نظام التسجيل والمتابعة الطلابية',
                  style: TextStyle(color: Colors.white70, fontSize: 12)),
            ),
          ),
        ),
        body: pages[index],
        bottomNavigationBar: NavigationBar(
          selectedIndex: index,
          onDestinationSelected: (v) => setState(() => index = v),
          destinations: const [
            NavigationDestination(icon: Icon(Icons.dashboard_outlined), label: 'الرئيسية'),
            NavigationDestination(icon: Icon(Icons.people_outline), label: 'الطلاب'),
            NavigationDestination(icon: Icon(Icons.fact_check_outlined), label: 'التسجيل السنوي'),
            NavigationDestination(icon: Icon(Icons.notifications_none), label: 'الإشعارات'),
          ],
        ),
      ),
    );
  }
}

class DashboardPage extends StatelessWidget {
  const DashboardPage({super.key});

  @override
  Widget build(BuildContext context) {
    return ListView(padding: const EdgeInsets.all(16), children: [
      Card(
        color: const Color(0xFF174766),
        child: const Padding(
          padding: EdgeInsets.all(18),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('لوحة متابعة التسجيل', style: TextStyle(color: Colors.white, fontSize: 21, fontWeight: FontWeight.bold)),
            SizedBox(height: 6),
            Text('العام الدراسي النشط: يحدد من إعدادات الإدارة', style: TextStyle(color: Colors.white70)),
          ]),
        ),
      ),
      const SizedBox(height: 12),
      const Wrap(spacing: 10, runSpacing: 10, children: [
        StatCard(title: 'إجمالي الطلاب', value: '—', icon: Icons.groups),
        StatCard(title: 'المسجلون', value: '—', icon: Icons.verified_user),
        StatCard(title: 'غير المسجلين', value: '—', icon: Icons.person_off),
        StatCard(title: 'طلبات المراجعة', value: '—', icon: Icons.pending_actions),
      ]),
      const SizedBox(height: 16),
      const Text('الكليات المعتمدة', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
      const SizedBox(height: 8),
      for (final c in ['كلية الاقتصاد', 'كلية المحاسبة', 'كلية القانون', 'كلية التمريض'])
        Card(child: ListTile(leading: const Icon(Icons.school), title: Text(c), subtitle: const Text('إحصاءات التسجيل تظهر بعد ربط قاعدة البيانات'))),
      if (!backendReady)
        const Card(
          color: Color(0xFFFFF3D9),
          child: Padding(
            padding: EdgeInsets.all(12),
            child: Text('وضع التصميم: لم يتم ربط قاعدة بيانات Supabase بعد. أدخل مفاتيح المشروع عند الإعداد لتفعيل البيانات الحقيقية.'),
          ),
        ),
    ]);
  }
}

class StatCard extends StatelessWidget {
  final String title, value;
  final IconData icon;
  const StatCard({super.key, required this.title, required this.value, required this.icon});
  @override
  Widget build(BuildContext context) => SizedBox(
    width: MediaQuery.of(context).size.width / 2 - 22,
    child: Card(child: Padding(
      padding: const EdgeInsets.all(14),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Icon(icon, color: const Color(0xFF174766)),
        const SizedBox(height: 10),
        Text(value, style: const TextStyle(fontSize: 25, fontWeight: FontWeight.bold)),
        Text(title, style: const TextStyle(color: Colors.black54)),
      ]),
    )),
  );
}

class StudentsPage extends StatelessWidget {
  const StudentsPage({super.key});
  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(16), children: [
    const Text('إدارة قاعدة الطلاب', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
    const SizedBox(height: 8),
    const Text('يضيف موظف التسجيل الطالب لأول مرة، ثم يُربط برقمه الجامعي وكلية الطالب.'),
    const SizedBox(height: 12),
    FilledButton.icon(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const AddStudentPage())),
      icon: const Icon(Icons.person_add), label: const Text('إضافة طالب جديد')),
    const SizedBox(height: 8),
    const SearchField(),
    const Card(child: ListTile(leading: Icon(Icons.info_outline), title: Text('لا توجد بيانات بعد'), subtitle: Text('أضف الطلاب أو استورد كشفاً منظماً بعد تهيئة قاعدة البيانات.'))),
  ]);
}

class SearchField extends StatelessWidget {
  const SearchField({super.key});
  @override
  Widget build(BuildContext context) => const TextField(
    decoration: InputDecoration(prefixIcon: Icon(Icons.search), hintText: 'بحث بالاسم أو الرقم الجامعي', border: OutlineInputBorder()),
  );
}

class AddStudentPage extends StatefulWidget {
  const AddStudentPage({super.key});
  @override
  State<AddStudentPage> createState() => _AddStudentPageState();
}
class _AddStudentPageState extends State<AddStudentPage> {
  final name = TextEditingController(), number = TextEditingController(), phone = TextEditingController();
  String college = 'كلية الاقتصاد';
  @override
  void dispose() { name.dispose(); number.dispose(); phone.dispose(); super.dispose(); }
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('إضافة طالب جديد')),
    body: ListView(padding: const EdgeInsets.all(16), children: [
      TextField(controller: name, decoration: const InputDecoration(labelText: 'الاسم الرباعي', border: OutlineInputBorder())),
      const SizedBox(height: 12),
      TextField(controller: number, decoration: const InputDecoration(labelText: 'الرقم الجامعي', border: OutlineInputBorder())),
      const SizedBox(height: 12),
      TextField(controller: phone, keyboardType: TextInputType.phone, decoration: const InputDecoration(labelText: 'رقم الهاتف (اختياري)', border: OutlineInputBorder())),
      const SizedBox(height: 12),
      DropdownButtonFormField<String>(
        value: college,
        decoration: const InputDecoration(labelText: 'الكلية', border: OutlineInputBorder()),
        items: ['كلية الاقتصاد','كلية المحاسبة','كلية القانون','كلية التمريض'].map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(),
        onChanged: (v) => setState(() => college = v!),
      ),
      const SizedBox(height: 20),
      FilledButton(onPressed: () {
        if (name.text.trim().isEmpty || number.text.trim().isEmpty) {
          ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('يرجى إدخال الاسم والرقم الجامعي')));
          return;
        }
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('واجهة الإدخال جاهزة؛ يلزم ربط قاعدة البيانات لحفظ الطالب فعلياً.')));
      }, child: const Text('حفظ بيانات الطالب')),
    ]),
  );
}

class AnnualRegistrationPage extends StatelessWidget {
  const AnnualRegistrationPage({super.key});
  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(16), children: [
    const Text('التسجيل السنوي', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
    const SizedBox(height: 8),
    const Text('كل طالب يحتاج إلى سجل مستقل لكل عام دراسي. لا يُعد الطالب مسجلاً إلا بعد اعتماد موظف التسجيل.'),
    const SizedBox(height: 12),
    Card(child: ListTile(leading: const Icon(Icons.calendar_month), title: const Text('العام الدراسي'), subtitle: const Text('يتم تحديد العام النشط من لوحة الإدارة'))),
    Card(child: ListTile(leading: const Icon(Icons.rule), title: const Text('حالات الطلب'), subtitle: const Text('قيد المراجعة • معتمد • مرفوض'))),
    Card(child: ListTile(leading: const Icon(Icons.person_search), title: const Text('كشف غير المسجلين'), subtitle: const Text('يُحسب من قائمة الطلاب النشطين الذين لا يملكون تسجيلاً معتمداً في العام النشط'))),
  ]);
}

class NoticesPage extends StatelessWidget {
  const NoticesPage({super.key});
  @override
  Widget build(BuildContext context) => const Center(
    child: Padding(padding: EdgeInsets.all(24), child: Column(mainAxisSize: MainAxisSize.min, children: [
      Icon(Icons.notifications_active_outlined, size: 54, color: Color(0xFF174766)),
      SizedBox(height: 12),
      Text('الإشعارات', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
      SizedBox(height: 6),
      Text('ستظهر هنا إشعارات اعتماد التسجيل والتنبيه باستكمال الإجراءات بعد ربط الخادم.'),
      ]),
    ),
  );
}
